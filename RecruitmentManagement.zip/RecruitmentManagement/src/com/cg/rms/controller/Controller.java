package com.cg.rms.controller;

public class Controller {

}
