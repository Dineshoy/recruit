package com.cg.rms.service;
import javax.transaction.Transactional;
import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.repo.IRmsRepo;

@Transactional
@Service
public class IRmsServiceImpl implements IRmsService {
	@Autowired
	IRmsRepo repo;
	
	public IRmsRepo getRepo() {
		return repo;
	}

	public void setRepo(IRmsRepo repo) {
		this.repo = repo;
	}

	public CompanyMaster addCompanyDetails(CompanyMaster company) {
		// TODO Auto-generated method stub
		
		return repo.addCompanyDetails(company);
	}

	

}
