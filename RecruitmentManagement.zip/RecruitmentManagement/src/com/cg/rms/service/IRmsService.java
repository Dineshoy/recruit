package com.cg.rms.service;

import com.cg.rms.beans.CompanyMaster;

public interface IRmsService {
	public CompanyMaster addCompanyDetails(CompanyMaster company);

}
