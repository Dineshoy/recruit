package com.cg.rms.repo;

import com.cg.rms.beans.CompanyMaster;

public class IRmsRepoImpl implements IRmsRepo {

	@Override
	public CompanyMaster addCompanyDetails(CompanyMaster company) {
		// TODO Auto-generated method stub
		return company;
	}

}
