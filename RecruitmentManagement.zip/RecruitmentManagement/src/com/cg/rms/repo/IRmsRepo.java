package com.cg.rms.repo;

import com.cg.rms.beans.CompanyMaster;

public interface IRmsRepo {
	
	public CompanyMaster addCompanyDetails(CompanyMaster company);

}
